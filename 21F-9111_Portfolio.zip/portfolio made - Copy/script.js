document.addEventListener('DOMContentLoaded', function () {
    const signUpForm = document.getElementById('signUpForm');
    const signInForm = document.getElementById('signInForm');
    const signUpData = JSON.parse(localStorage.getItem('signUpData')) || {};

    signUpForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const email = document.getElementById('email').value;
        const age = document.getElementById('age').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const address = document.getElementById('address').value;
        const city = document.getElementById('city').value;
        const state = document.getElementById('state').value;
        const zip = document.getElementById('zip').value;

        if (!isValidEmail(email)) {
            showMessage('Email address is not valid');
            return;
        }

        if (!isValidPassword(password)) {
            showMessage('Password must contain at least one special and one numeric character, and be at least 8 characters long');
            return;
        }

        if (password !== confirmPassword) {
            showMessage('Passwords do not match');
            return;
        }

        localStorage.setItem('signUpData', JSON.stringify({ firstName, lastName, email, age, password, address, city, state, zip }));
        showMessage('Sign up successful');
    });

    signInForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        if (username === signUpData.email && password === signUpData.password) {
            showMessage('You have successfully signed in to your account');
        } else {
            showMessage('Invalid username or password');
        }
    });

    function isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    function isValidPassword(password) {
        const regex = /^(?=.*[!@#$%^&*])(?=.*\d).{8,}$/;
        return regex.test(password);
    }

    function showMessage(message) {
        const messageDiv = document.getElementById('message');
        messageDiv.textContent = message;
    }
});
